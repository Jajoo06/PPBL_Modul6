import 'package:flutter/material.dart';

import '../pages/halaman_laporan.dart';
import '../pages/halaman_detail_laporan.dart';
import '../pages/halaman_profil.dart';
import '../pages/halaman_pengaturan.dart';
import '../navigation/kerangka_navigasi.dart';

class AppRoutes {
  static const String beranda = '/';
  static const String laporan = '/laporan';
  static const String detailLaporan = '/detail-laporan';
  static const String profil = '/profil';
  static const String pengaturan = '/pengaturan';
  static const String tentang = '/tentang';

  static Map<String, WidgetBuilder> daftarRoute() {
    return {
      beranda: (context) =>
          const KerangkaNavigasi(), // Ganti ini dari HalamanBeranda()
      laporan: (context) => const HalamanLaporan(),
      profil: (context) => const HalamanProfil(),
      pengaturan: (context) => const HalamanPengaturan(),
    };
  }

  static Route<dynamic>? bentukRoute(RouteSettings settings) {
    if (settings.name == detailLaporan) {
      final arguments = settings.arguments;
      String idLaporan = 'LAP-001';

      // Mendukung jika argumen dikirim berupa String langsung (id)
      if (arguments is String) {
        idLaporan = arguments;
      }
      // Mendukung jika argumen dikirim berupa Map dari Modul II sebelumnya
      else if (arguments is Map<String, dynamic>) {
        idLaporan = arguments['id'] ?? arguments['judul'] ?? 'LAP-001';
      }

      return MaterialPageRoute(
        builder: (context) => HalamanDetailLaporan(idLaporan: idLaporan),
        settings: settings,
      );
    }

    return null;
  }

  static Route<dynamic> routeTidakDikenal(RouteSettings settings) {
    return MaterialPageRoute(
      builder: (context) {
        return Scaffold(
          appBar: AppBar(title: const Text('Halaman Tidak Ditemukan')),
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline, size: 80, color: Colors.red),
                  const SizedBox(height: 16),
                  const Text(
                    'Route Tidak Ditemukan',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Route "${settings.name}" tidak tersedia.',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  FilledButton.icon(
                    onPressed: () {
                      Navigator.pushNamedAndRemoveUntil(
                        context,
                        AppRoutes.beranda,
                        (route) => false,
                      );
                    },
                    icon: const Icon(Icons.home),
                    label: const Text('Kembali ke Beranda'),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
