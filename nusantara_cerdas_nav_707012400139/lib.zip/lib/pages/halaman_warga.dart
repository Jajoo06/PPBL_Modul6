import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../cubit/favorit_cubit.dart';
import '../cubit/pengajuan_cubit.dart';
import '../navigation/app_routes.dart';

class HalamanWarga extends StatelessWidget {
  const HalamanWarga({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Keranjang Pengajuan',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            BlocSelector<PengajuanCubit, List<String>, int>(
              selector: (state) => state.length,
              builder: (context, total) {
                return Chip(
                  label: Text('$total item'),
                  backgroundColor: Colors.teal.shade50,
                );
              },
            ),
          ],
        ),
        const SizedBox(height: 8),
        BlocBuilder<PengajuanCubit, List<String>>(
          builder: (context, daftarPengajuan) {
            if (daftarPengajuan.isEmpty) {
              return const Card(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Belum ada layanan yang diajukan.',
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              );
            }
            return Column(
              children: daftarPengajuan.map((nama) {
                return Card(
                  child: ListTile(
                    leading: const Icon(
                      Icons.assignment_turned_in,
                      color: Colors.teal,
                    ),
                    title: Text(nama),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.red),
                      onPressed: () {
                        context.read<PengajuanCubit>().hapusPengajuan(nama);
                      },
                    ),
                  ),
                );
              }).toList(),
            );
          },
        ),
        const Divider(height: 36),
        const Text(
          'Layanan Favorit',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        BlocBuilder<FavoritCubit, List<String>>(
          builder: (context, daftarFavorit) {
            if (daftarFavorit.isEmpty) {
              return const Card(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Belum ada layanan favorit.',
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              );
            }
            return Column(
              children: daftarFavorit.map((nama) {
                return Card(
                  child: ListTile(
                    leading: const Icon(Icons.star, color: Colors.amber),
                    title: Text(nama),
                    trailing: TextButton(
                      child: const Text('Buka'),
                      onPressed: () {
                        Navigator.pushNamed(
                          context,
                          AppRoutes.detailLayanan,
                          arguments: nama,
                        );
                      },
                    ),
                  ),
                );
              }).toList(),
            );
          },
        ),
      ],
    );
  }
}
